class HomePageData:
    test_HomePage_data = [{"firstname": "Rahul", "lastname": "shetty", "gender": "Male"},
                          {"firstname": "Harpreet", "lastname": "shetty", "gender": "Female"}]
