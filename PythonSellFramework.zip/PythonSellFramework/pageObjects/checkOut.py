from selenium.webdriver.common.by import By


class CheckoutPage:
    cardTitle = (By.XPATH, "//div[@class='card h-100']")
    cardName = (By.XPATH, "div/h4/a")
    cardFooter = (By.XPATH, "div/button")

    def __init__(self, driver):
        self.driver = driver

    def getCardTitle(self):
        return self.driver.find_elements(*CheckoutPage.cardTitle)

    def getCardName(self):
        return self.driver.find_element(*CheckoutPage.cardName)

    def getCardFooter(self):
        return self.driver.find_element(*CheckoutPage.cardFooter)

