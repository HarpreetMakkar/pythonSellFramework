
from pageObjects.checkOut import CheckoutPage
from pageObjects.homePage import HomePage
from utilities.BaseClass import BaseClass


class TestOne(BaseClass):

    def test_one(self):
        log = self.test_log()
        homePage = HomePage(self.driver)
        checkoutpage = homePage.shopItems()
        log.info("getting all card title")
        products = checkoutpage.getCardTitle()

        for product in products:
            productName = product.find_element_by_xpath("div/h4/a").text
            log.info(productName)
            if productName == "Blackberry":
                product.find_element_by_xpath("div/button").click()

        self.driver.find_element_by_css_selector("a[class*='btn-primary']").click()

        self.driver.find_element_by_xpath("//button[@class='btn btn-success']").click()

        self.driver.find_element_by_id("country").send_keys("ind")

        self.verifyLinkPresence("India")

        self.driver.find_element_by_link_text("India").click()

        self.driver.find_element_by_xpath("//div[@class='checkbox checkbox-primary']").click()

        self.driver.find_element_by_css_selector("[type='submit']").click()

        print(self.driver.find_element_by_class_name("alert-success").text)

        self.driver.get_screenshot_as_file("screen.png")
